﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using Telephone;
using System.Linq;
using System.Xml.Linq;

namespace Telephone
{
    class Program
    {
        static void Print(List<TelephoneGuide> TG)
        {
            if (TG.Count > 0)
            {
                Console.WriteLine("********");
                foreach (var t in TG)
                {
                    t.GetInfo();
                }
                Console.WriteLine("********");
            }
            else
            {
                Console.WriteLine("Нет элементов в списке");
            }
        }

        static void Main(string[] args)
        {
            List<TelephoneGuide> TG = new List<TelephoneGuide>();
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream f = new FileStream("C:\\Users\\timofeevavm\\source\\repos\\seregalizacia\\seregalizacia\\input.dat",
             FileMode.OpenOrCreate))
            {
                if (f.Length != 0)
                {
                    TG = (List<TelephoneGuide>)formatter.Deserialize(f);
                }
            }
            Print(TG);


            TG.Add(new Person("Timofeeva", "ul.Grigorjeva", "79658"));

            TG.Add(new Person("Ivanov", "ul.Lermontova", "22222"));
            TG.Add(new Person("Sidorova", "ul.Sovetskaya", "36945"));
            TG.Add(new Person("Drozdov", "ul.Rahova", "10701"));
            TG.Add(new Friend("Malisheva", "ul.Sapernaya", "96345", "24.08.2004"));
            TG.Add(new Friend("Razinov", "ul.Voznesenskaya", "10011", "12.05.2004"));
            TG.Add(new Ogranization(new string[] { "Peredreeva", "Sheglova" }, "ul.Universitetskaya", "22041", "77-32-84", "SPA"));
            TG.Add(new Ogranization(new string[] { "Fedorov", "Ryblov", "Shevtsov" }, "ul.Volskaya", "10771", "44-35-64", "Malyata"));

            Print(TG);
            TG.Sort();
            Print(TG);
            string[] sur = { "Fedorov" };
            var findBySurname =
                from pers in TG
                where pers.InGuide(sur)[0] == true
                select pers;

            List<TelephoneGuide> find_sur = new List<TelephoneGuide>();
            foreach (var s in findBySurname)
            {
                find_sur.Add(s);
            }
            Print(find_sur);

            using (FileStream f = new FileStream("C:\\Users\\timofeevavm\\source\\repos\\seregalizacia\\seregalizacia\\input.dat",
                    FileMode.OpenOrCreate))
            {
                formatter.Serialize(f, TG);
            }
        }
    }
}

