﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using Telephone;
using System.Xml.Linq;

namespace Telephone
{
    class Program
    {
        static void Print(List<TelephoneGuide> TG)
        {
            if (TG.Count > 0)
            {
                Console.WriteLine("--------");
                foreach (var t in TG)
                {
                    t.GetInfo();
                }
                Console.WriteLine("--------");
            }
            else
            {
                Console.WriteLine("Нет элементов в списке");
            }
        }

        static void Main(string[] args)
        {
            List<TelephoneGuide> TG = new List<TelephoneGuide>();
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream f = new FileStream("input.dat",
             FileMode.OpenOrCreate))
            {
                if (f.Length != 0)
                {
                    TG = (List<TelephoneGuide>)formatter.Deserialize(f);
                }
            }
            Print(TG);


            //TG.Add(new Person("Тимофеева", "ул.Григорьева", "789651"));

            //TG.Add(new Person("Наумчик", "ул.Радищева", "469312"));
            //TG.Add(new Person("Радченко", "ул.Чапаева", "134961"));
            //TG.Add(new Person("Фёдоров", "ул.Вознесенская", "325981"));
            //TG.Add(new Friend("Разинов", "ул.Вознесенская", "932984", "12.05.2004"));
            //TG.Add(new Friend("Малышева", "ул.Саперная", "364785", "24.08.2004"));
            //TG.Add(new Ogranization(new string[] { "Соколова", "Яковлева" }, "ул.Кутякова", "219865", "12-32-84", "Safia"));
            //TG.Add(new Ogranization(new string[] { "Фифа", "Кира", "Маргоша" }, "ул.Чернышевского", "753214", "54-35-64", "PETS"));

            Print(TG);
            TG.Sort();
            Print(TG);
            string[] sur = { "Кира" };
            var findBySurname =
                from pers in TG
                where pers.InGuide(sur)[0] == true
                select pers;

            List<TelephoneGuide> find_sur = new List<TelephoneGuide>();
            foreach (var s in findBySurname)
            {
                find_sur.Add(s);
            }
            Print(find_sur);

            using (FileStream f = new FileStream("input.dat",
                    FileMode.OpenOrCreate))
            {
                formatter.Serialize(f, TG);
            }
        }
    }
}