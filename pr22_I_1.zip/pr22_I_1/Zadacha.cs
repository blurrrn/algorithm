﻿using ClassG;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr22_I_1
{
    class Zadacha
    {
            static void Main()
            {
                Graph g = new Graph("input.txt"); // Чтение входного файла

                g.Show();
                g.InputNodes(1);

            }
    }
}
